/**
 * Arquivo-cabeçalho contendo as declarações da classe Grafo
 * e seus atributos e métodos.
 * 
 * @author Lucas Vinicius M. Pinheiro
 * @author Luthiery C. Cavalcante
 */
#ifndef _grafo_
#define _grafo_
#include "vertice.h"
#include <vector>

using namespace std;

/**
 * @brief      Classe Grafo, que usa um vetor interno para armazenar seus vértices.
 */
class Grafo {
	/**
	 * Representa o conjunto de vértices do grafo.
	 */
	vector<Vertice> vertices;

public:
	/**
	 * @brief      Cria um grafo vazio.
	 */
	Grafo();

	/**
	 * Cria um grafo com uma dada quantidade de vértices n,
	 * nomeados de 1 a n.
	 * 
	 * @param[in]  n	A quantidade de vértices desejada.
	 */
	Grafo(int n);

	/**
	 * @brief      Extrai vértices e arestas do arquivo "karate.txt" para o grafo.
	 */
	void lerArquivo();

	/**
	 * @brief      Adiciona um vértice no vetor.
	 *
	 * @param[in]  id    O id do vértice
	 */
	void addVertice(int id);

	/**
	 * @brief      Adiciona uma aresta entre os vértices a e b, se ela já não existir.
	 *
	 * @param[in]  id_a  O id do vértice a
	 * @param[in]  id_b  O id do vértice b
	 */
	void addAresta(int id_a, int id_b);

	/**
	 * @brief      Checa se existe uma aresta entre dois vértices a e b.
	 *
	 * @param[in]  id_a  O id do vértice a
	 * @param[in]  id_b  O id do vértice b
	 *
	 * @return     true, caso exista uma aresta; false, caso contrário.
	 */

	bool existeAresta(int id_a, int id_b);

	/**
	 * @brief      Retorna uma referência para o vértice de id (id).
	 *
	 * @param[in]  id    O id desejado
	 *
	 * @return     O vértice encontrado, caso exista. Lança uma exceção, caso contrário.
	 */
	Vertice& getVertice(int id);

	/**
	 * @brief      Checa se o grafo é conectado, isto é,
	 * checa se cada vértices possui ao menos uma ligação com qualquer outro.
	 *
	 * @return     true, se o grafo é conectado; false, caso contrário.
	 */
	bool conectado();

	/**
	 * @brief      Recupera o grau do grafo, isto é,
	 * o maior grau entre seus vértices.
	 *
	 * @return     int	O valor do grau.
	 */
	int grau();

	/**
	 * @brief      Mostra na tela os graus de cada vértice e do próprio grafo.
	 */
	void imprimeGraus();

	/**
	 * @brief      Imprime o grafo na tela.
	 * 
	 * Mostra cada vértice e sua respectiva lista de adjacências.
	 */
	void imprime();

	/**
	 * @brief      Mostra na tela os coeficientes de aglomeração
	 * do grafo e de cada vértice.
	 */
	void coefAglomeracao();
};
#endif
