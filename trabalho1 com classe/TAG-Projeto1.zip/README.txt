Projeto I de Teoria e Aplicações de Grafos - TAG
Professor Díbio
Alunos: 
	Luthiery Costa Cavalcante 		(17/0040631)
	Lucas Vinicius Magalhães Pinheiro	(17/0061001)

Implementação de um programa que recebe um doc .txt contendo informações
sobre um grafo de relações e o representa digitalmente, calculando o grau
de cada vértice no grafo e seu coeficiente de aglomeração e o coeficiente
de aglomeração médio do grafo.
