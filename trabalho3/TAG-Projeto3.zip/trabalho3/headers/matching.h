/**
 * Arquivo-cabeçalho contendo as declarações da função de matching
 * 
 * @author Lucas Vinicius M. Pinheiro
 * @author Luthiery C. Cavalcante
 */
#ifndef _matching_
#define _matching_

#include "../headers/grafo.h"
#include <bits/stdc++.h>

using namespace std;

/**
 * @brief      Função auxiliar do emparelhamento, que retorna a soma dos inteiros de um vector<int>
 *
 * @param	vector<int> vetor	O vector de int a ser percorrido
 * @return	int soma		Soma dos inteiros do vector 	
 */
int soma(vector<int> vetor);

/**
 * @brief	Função principal para "matching" ou emparelhamento, funcionando com base no algoritmo Gale-Shapley. 
 *
 * 		Primeiramente, cria-se 2 vector de int, um com o número de professores e outro com número de escolas, ambos inicializados
 * em -1, que representará disponibilidade (professor não empregado, ou escola com vaga)
 *		Após isso, percorremos cada um dos professores e tentamos empregar ele em uma das escolas de sua lista,
 * checando se o professor já não estã empregado em uma escola que ele prefira, se a escola atual ainda tem vaga, se o professor
 * é ou não apto para uma das duas vagas (no caso de haver duas vagas) e caso a vaga esteja ocupada, se o professor atual não
 * é melhor do professor previamente escolhido para a vaga, caso seja o previamente escolhido é recusado e o atual é escolhido
 * em seu lugar.
 *		Sempre que um professor for escolhido, marcaremos em um vector<pair<int, int> > com o número de escolas, na posição
 * da escola atual, a vaga que o professor atual ocupará. caso ocupe a segunda vaga (no caso de houverem duas vagas), por exemplo, 
 * a posição [escola_atual].second será igual ao int id do professor atual. Caso a escola troque de professores para a vaga, esse 
 * campo será atualizado com o novo professor. Ao final do algoritmo, esse vector<pair<int, int> > conterá as informações sobre 
 * quais professores foram contratados por quais escolas. 
 *
 * @param	Grafo& grafo			O grafo bipartido a ser analisado
 * @return	vector<pair<int, int> > pares	O vector com as informações de "contratações"
 */
vector<pair<int, int> > matching(Grafo& grafo);


#endif
